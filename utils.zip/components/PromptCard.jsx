import React from 'react'

const PromptCard = () => {
  return (
    <div>PromptCard</div>
  )
}

export default PromptCard